`timescale 1ns / 1ps

module ALU_4bit(

    input  logic [3:0] A,
    input  logic [3:0] B,
    input  logic [2:0] Operation,
    output logic [3:0] Output,
    output logic n,
    output logic z,
    output logic o, 
    output logic c  
);

    logic [4:0] result_ext;

    always_comb begin
        
        c = 1'b0;
        o = 1'b0;
        result_ext = 5'b00000;

        case (Operation)
            3'b000: begin 
                result_ext = A + B;
                c = result_ext[4];
                
                o = (~A[3] & ~B[3] & result_ext[3]) | (A[3] & B[3] & ~result_ext[3]);
            
            end
            
            3'b001: begin // A - B
                result_ext = A - B;
                c = result_ext[4]; 
                o = (~A[3] & B[3] & result_ext[3]) | (A[3] & ~B[3] & ~result_ext[3]);
            
            end
            3'b010: result_ext = {1'b0, A & B};
            3'b011: result_ext = {1'b0, A | B};
            3'b100: result_ext = {1'b0, A ^ B};
            3'b101: result_ext = {1'b0, ~A};
            3'b110: result_ext = {1'b0, A << 1};
            3'b111: result_ext = {1'b0, A >> 1};
            default: result_ext = 5'b00000;
        endcase

        Output = result_ext[3:0];
        n = Output[3];                  
        z = (Output == 4'b0000);        
    end
    
endmodule