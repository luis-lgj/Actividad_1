`timescale 1ns / 1ps

module tb_ALU_4bit();

    logic [3:0] A;
    logic [3:0] B;
    logic [2:0] Operation;
    
    logic [3:0] Output;
    logic n, z, o, c;

    ALU_4bit uut (
        .A(A),
        .B(B),
        .Operation(Operation),
        .Output(Output),
        .n(n),
        .z(z),
        .o(o),
        .c(c)
    );

    initial begin
        // PRUEBAS DE SUMA (Operation = 000)
        Operation = 3'b000;
        
        A = 4'b0010; B = 4'b0011; // 2 + 3 = 5
        #10; 
        // Prueba 2 Suma con Acarreo (Carry) y Cero (Zero)
        A = 4'b1111; B = 4'b0001; // 15 + 1 = 16
        #10;
        
        // Prueba 3 Suma con Desborde (Overflow)
        A = 4'b0111; B = 4'b0001; // 7 + 1 = 8 
        #10; 

        //PRUEBAS DE RESTA (Operation = 001)
        Operation = 3'b001;
        
        // Prueba 4: Resta que da cero
        A = 4'b0101; B = 4'b0101; // 5 - 5 = 0
        #10; 
        // Prueba 5: Resta que da negativo
        A = 4'b0010; B = 4'b0110; 
        #10; 

        // PRUEBAS LÓGICAS BIT A BIT 
        A = 4'b1100; B = 4'b1010;
        
        //  AND 
        Operation = 3'b010; // 1100 & 1010 = 1000
        #10;
        
        // OR 
        Operation = 3'b011; // 1100 | 1010 = 1110
        #10;
        
        //  XOR 
        Operation = 3'b100; // 1100 ^ 1010 = 0110
        #10;
        
        //  NOT
        Operation = 3'b101; // ~1100 = 0011
        #10;

        // PRUEBAS DE CORRIMIENTO
        A = 4'b0011; // 3 en decimal
        
        // Shift Left 
        Operation = 3'b110; // 0011 << 1 = 0110 
        #10;
        
        // Shift Right 
        Operation = 3'b111; // 0011 >> 1 = 0001 
        #10;

        $finish;
    end

endmodule